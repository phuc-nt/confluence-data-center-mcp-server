# Project Roadmap Template

## 1. Trạng thái dự án
- Progress: [Not Started/In Progress/Completed]
- Tổng số sprint/tasks: [Số lượng]

## 2. Kế hoạch từng sprint/task

| Sprint/Task | Status | Mục tiêu | Thời gian | Tiến độ |
|-------------|--------|----------|-----------|---------|
| Sprint 1    |        |          |           |         |
| Sprint 2    |        |          |           |         |
| ...         |        |          |           |         |

## 3. Milestone & tiêu chí hoàn thành

- [Milestone 1]: [Mô tả, điều kiện hoàn thành]
- [Milestone 2]: [Mô tả, điều kiện hoàn thành]
- ...

## 4. Rủi ro & phương án xử lý

| Rủi ro           | Ảnh hưởng | Xác suất | Phương án xử lý |
|------------------|-----------|----------|-----------------|
|                  |           |          |                 |

## 5. Liên kết tài liệu liên quan
- [Link tới các tài liệu khác nếu có]
