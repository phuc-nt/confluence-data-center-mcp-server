# Yêu cầu nghiệp vụ dự án (Business Requirements Template)

## 1. Mục tiêu dự án
[Mô tả mục tiêu tổng quan, giá trị mang lại, đối tượng sử dụng]

## 2. Phạm vi
[Liệt kê phạm vi chức năng, nghiệp vụ, giới hạn dự án]

## 3. Tiêu chí thành công
[Định nghĩa các chỉ số, điều kiện để dự án được coi là thành công]

## 4. Yêu cầu chi tiết
- [Yêu cầu 1]: [Mô tả]
- [Yêu cầu 2]: [Mô tả]
- ...

## 5. Ràng buộc & giả định
[Ràng buộc kỹ thuật, nghiệp vụ, nguồn lực, giả định ban đầu]

## 6. Liên kết tài liệu liên quan
- [Link tới các tài liệu khác nếu có]
